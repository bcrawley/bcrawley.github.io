/* global powerbi */
var token, groupId, reportId, datasetIds, customEmbed, pageName, embedToken, filtersEnabled, navContentPaneEnabled, defaultFilters, connectedSystem, url;
filtersEnabled = true;
navContentPaneEnabled = true;
pageName = '';

function resetReport() {
    var config = {
        type: 'report',
        tokenType: 1,
        // 0 is for Aad token which is needed for "user owns data" scenario
        accessToken: embedToken,
        embedUrl: url,
        id: reportId,
        pageName: pageName,
        permissions: 7,
        filters: defaultFilters,
        settings: {
            filterPaneEnabled: filtersEnabled,
            navContentPaneEnabled: navContentPaneEnabled,
            background: 1
        }
    };
    var embedContainer = $('#paginatedReportContainer')[0];
    var report = powerbi.embedNew(embedContainer, config);

    report.off('dataSelected');
    report.on('dataSelected', function(data) {
        Appian.Component.saveValue('onDataSelected', {
            dataPoints: JSON.stringify(data.detail.dataPoints),
            page: data.detail.page,
            report: data.detail.report,
            visual: data.detail.visual
        });
    });

    report.off('pageChanged');
    report.on('pageChanged', function(page) {
        Appian.Component.saveValue('onPageChanged', {
            displayName: page.detail.newPage.displayName,
            name: page.detail.newPage.name
        });
    });

    report.off('error');
    report.on('error', function(event) {
        Appian.Component.saveValue('onError', {
            event: event.detail
        });
    });
}

function buildDataObject(datasetIds, reportId) {
    // Create the datasets array by mapping over datasetIds
    const datasets = datasetIds.map(id => ({
        id: id,
        xmlaPermissions: "ReadOnly"
    }));

    // Construct the final object
    const dataObject = {
        datasets: datasets,
        reports: [
            {
                "id": reportId
            }
        ]
    };

    // Convert the object to a JSON string
    return JSON.stringify(dataObject);
}

Appian.Component.onNewValue(function(newParameters) {
    document.body.style.height = newParameters['height'];
    groupId = newParameters['groupId'];
    reportId = newParameters['reportId'];
    pageName = newParameters['pageName'];
    filtersEnabled = newParameters['showFilters'];
    navContentPaneEnabled = newParameters['showPageNavigation'];
    defaultFilters = newParameters['defaultFilters'];
    connectedSystem = newParameters['powerBIConnectedSystem'];
    datasetIds = newParameters['datasetIds'];
    customEmbed = newParameters['customEmbed'];
    if (connectedSystem != null && reportId != null) {
        var payload = groupId ? {
            groupId: groupId,
            reportId: reportId,
            pageName: pageName,
            filtersEnabled: filtersEnabled,
            navContentPaneEnabled: navContentPaneEnabled,
            embedType: 0
        } : {
            reportId: reportId,
            pageName: pageName,
            filtersEnabled: filtersEnabled,
            navContentPaneEnabled: navContentPaneEnabled,
            embedType: 0
        };
        Appian.Component.invokeClientApi(connectedSystem, 'GenerateEmbedTokenClientApi', payload).then(function(response) {
                Appian.Component.setValidations([]);
                token = response.payload.token;
                url = 'https://app.powerbi.com/rdlEmbed?reportId=' + reportId;
                if (groupId) {
                    url = url + '&groupId=' + groupId;
                }
                if (!(groupId && reportId)) {
                    Appian.Component.setValidations("Group Id or Report Id should not be null.");
                    return;
                }    
                if(!(datasetIds && customEmbed)){
                    Appian.Component.setValidations("Either Dataset Ids or Custom Embed Object should not be null.");
                    return;
                }
                var xhr = new XMLHttpRequest();
                var tokenUrl = "https://api.powerbi.com/v1.0/myorg/GenerateToken";
                xhr.open("POST", tokenUrl, true);
                xhr.setRequestHeader("Authorization", "Bearer " + token);
                xhr.setRequestHeader("Content-Type", "application/json");
                xhr.onreadystatechange = function() {
                    if (xhr.readyState === 4 && xhr.status === 200) {
                        var json = JSON.parse(xhr.responseText);
                        embedToken = json["token"];
                        resetReport();
                    } else if (xhr.readyState === 4 && xhr.status !== 200) {
                        Appian.Component.setValidations("Error happened while fetching embed token. Please check whether the inputs are valid.");
                    }
                }

                var data = (customEmbed != null) ? JSON.stringify(customEmbed) : buildDataObject(datasetIds, reportId);

                xhr.send(data);
            })
            .catch(function(error) {
                Appian.Component.setValidations(error);
            });
    }
});