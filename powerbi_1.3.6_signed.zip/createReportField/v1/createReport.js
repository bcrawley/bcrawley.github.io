/* global powerbi */
var token, groupId, connectedSystem, tokenType, embedToken, datasetId;
function resetReport() {
  var config = {
    tokenType: tokenType,
    accessToken: tokenType ? embedToken : token,
    embedUrl: 'https://embedded.powerbi.com/ReportEmbed',
    datasetId: datasetId,
    settings: {
      background: 1
    }
  };
  var embedContainer = $('#reportContainer')[0];
  var report = powerbi.createReport(embedContainer, config);

  report.off('loaded');
  report.on('loaded', function () { });

  report.off('error');
  report.on('error', function (event) {
    Appian.Component.saveValue('onError', {
      event: event.detail
    });
  });

  report.off('saved');
  report.on('saved', function (event) {
    Appian.Component.saveValue('onSave', {
      event: event.detail
    });
  });
}

Appian.Component.onNewValue(function (newParameters) {
  document.body.style.height = newParameters['height'];
  groupId = newParameters['groupId'];
  datasetId = newParameters['datasetId'];
  tokenType = newParameters['isAppDataConnectedSystem'] ? 1 : 0;
  connectedSystem = newParameters['powerBIConnectedSystem'];
  if (connectedSystem != null && datasetId != null) {
    var payload = groupId ? { groupId: groupId, datasetId: datasetId, embedType: 0 } : { datasetId: datasetId, embedType: 0 };
    Appian.Component.invokeClientApi(connectedSystem, 'GenerateEmbedTokenClientApi', payload).then(function (response) {
      Appian.Component.setValidations([]);
      token = response.payload.token;
      if (tokenType) {
        if (!(groupId && datasetId)) {
          Appian.Component.setValidations("Group Id or Dataset Id should not be null.");
          return;
        }
        var xhr = new XMLHttpRequest();
        var tokenUrl = "https://api.powerbi.com/v1.0/myorg/groups/" + groupId + "/reports/GenerateToken";
        xhr.open("POST", tokenUrl, true);
        xhr.setRequestHeader("Authorization", "Bearer " + token);
        xhr.setRequestHeader("Content-Type", "application/json");
        xhr.onreadystatechange = function () {
          if (xhr.readyState === 4 && xhr.status === 200) {
            var json = JSON.parse(xhr.responseText);
            embedToken = json["token"];
            resetReport();
          }
          else if (xhr.readyState === 4 && xhr.status !== 200) {
            Appian.Component.setValidations("Error happened while fetching embed token. Please check whether the inputs are valid.");
          }
        }
        var data = JSON.stringify({
          "accessLevel": "Create",
          "datasetId": datasetId
        });
        xhr.send(data);
      }
      else {
        resetReport();
      }
    })
      .catch(function (error) {
        Appian.Component.setValidations(error);
      });
  }
});