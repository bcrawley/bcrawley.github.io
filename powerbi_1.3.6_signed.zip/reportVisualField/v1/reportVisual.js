/* global powerbi */
var token, groupId, reportId, pageName, visualName, tokenType, embedToken, defaultFilters, connectedSystem, url;

function resetReportVisual() {
    var config = {
        type: 'visual',
        tokenType: tokenType,
        // 0 is for Aad token which is needed for "user owns data" scenario
        accessToken: tokenType ? embedToken : token,
        embedUrl: url,
        id: reportId,
        pageName: pageName,
        permissions: 7,
        filters: defaultFilters,
        visualName: visualName
    };
    var embedContainer = $('#reportVisualContainer')[0];
    var reportVisual = powerbi.embedNew(embedContainer, config);
    reportVisual.off('loaded');
    reportVisual.on('loaded', function() {});

    reportVisual.off('error');
    reportVisual.on('error', function(event) {
        Appian.Component.saveValue('onError', {
            event: event.detail
        });
    });

    reportVisual.on('visualClicked', function (event) {
                     Appian.Component.saveValue('onVisualClicked', {
                       event: event.detail
                     });
                   });
}
Appian.Component.onNewValue(function(newParameters) {
    document.body.style.height = newParameters['height'];
    groupId = newParameters['groupId'];
    reportId = newParameters['reportId'];
    pageName = newParameters['pageName'];
    visualName = newParameters['visualName'];
    defaultFilters = newParameters['defaultFilters'];
    tokenType = newParameters['isAppDataConnectedSystem'] ? 1 : 0;
    connectedSystem = newParameters['powerBIConnectedSystem'];
    if (connectedSystem != null && reportId != null) {
        var payload = groupId ? {
            groupId: groupId,
            reportId: reportId,
            pageName: pageName,
            visualName: visualName,
            embedType: 0
        } : {
            reportId: reportId,
            pageName: pageName,
            visualName: visualName,
            embedType: 0
        };
        Appian.Component.invokeClientApi(connectedSystem, 'GenerateEmbedTokenClientApi', payload).then(function(response) {
                Appian.Component.setValidations([]);
                token = response.payload.token;
                url = 'https://app.powerbi.com/reportEmbed?reportId=' + reportId;
                if (groupId) {
                    url = url + '&groupId=' + groupId;
                }
                if (tokenType) {
                    if (!(groupId && reportId)) {
                        Appian.Component.setValidations("Group Id or Report Id should not be null.");
                        return;
                    }
                    var xhr = new XMLHttpRequest();
                    var tokenUrl = "https://api.powerbi.com/v1.0/myorg/groups/" + groupId + "/reports/" + reportId + "/GenerateToken";
                    xhr.open("POST", tokenUrl, true);
                    xhr.setRequestHeader("Authorization", "Bearer " + token);
                    xhr.setRequestHeader("Content-Type", "application/json");
                    xhr.onreadystatechange = function() {
                        if (xhr.readyState === 4 && xhr.status === 200) {
                            var json = JSON.parse(xhr.responseText);
                            embedToken = json["token"];
                            resetReportVisual();
                        } else if (xhr.readyState === 4 && xhr.status !== 200) {
                            Appian.Component.setValidations("Error happened while fetching embed token. Please check whether the inputs are valid.");
                        }
                    }
                    var data = JSON.stringify({
                        "accessLevel": "View"
                    });
                    xhr.send(data);
                } else {
                    resetReportVisual();
                }
            })
            .catch(function(error) {
                Appian.Component.setValidations(error);
            });
    }
});