/* global powerbi */
var token, groupId, reportId, pageName, tokenType, embedToken, filtersEnabled, navContentPaneEnabled, defaultFilters, connectedSystem, url;
filtersEnabled = true;
navContentPaneEnabled = true;
pageName = '';

function resetReport() {
    var config = {
        type: 'report',
        tokenType: tokenType,
        // 0 is for Aad token which is needed for "user owns data" scenario
        accessToken: tokenType ? embedToken : token,
        embedUrl: url,
        id: reportId,
        pageName: pageName,
        permissions: 7,
        filters: defaultFilters,
        settings: {
            filterPaneEnabled: filtersEnabled,
            navContentPaneEnabled: navContentPaneEnabled,
            background: 1
        }
    };
    var embedContainer = $('#reportContainer')[0];
    var report = powerbi.embedNew(embedContainer, config);
    report.off('loaded');
    report.on('loaded', function() {});

    report.off('dataSelected');
    report.on('dataSelected', function(data) {
        Appian.Component.saveValue('onDataSelected', {
            dataPoints: JSON.stringify(data.detail.dataPoints),
            page: data.detail.page,
            report: data.detail.report,
            visual: data.detail.visual
        });
    });

    report.off('pageChanged');
    report.on('pageChanged', function(page) {
        Appian.Component.saveValue('onPageChanged', {
            displayName: page.detail.newPage.displayName,
            name: page.detail.newPage.name
        });
    });

    report.off('error');
    report.on('error', function(event) {
        Appian.Component.saveValue('onError', {
            event: event.detail
        });
    });
}
Appian.Component.onNewValue(function(newParameters) {
    document.body.style.height = newParameters['height'];
    groupId = newParameters['groupId'];
    reportId = newParameters['reportId'];
    pageName = newParameters['pageName'];
    filtersEnabled = newParameters['showFilters'];
    navContentPaneEnabled = newParameters['showPageNavigation'];
    defaultFilters = newParameters['defaultFilters'];
    tokenType = newParameters['isAppDataConnectedSystem'] ? 1 : 0;
    connectedSystem = newParameters['powerBIConnectedSystem'];
    if (connectedSystem != null && reportId != null) {
        var payload = groupId ? {
            groupId: groupId,
            reportId: reportId,
            pageName: pageName,
            filtersEnabled: filtersEnabled,
            navContentPaneEnabled: navContentPaneEnabled,
            embedType: 0
        } : {
            reportId: reportId,
            pageName: pageName,
            filtersEnabled: filtersEnabled,
            navContentPaneEnabled: navContentPaneEnabled,
            embedType: 0
        };
        Appian.Component.invokeClientApi(connectedSystem, 'GenerateEmbedTokenClientApi', payload).then(function(response) {
                Appian.Component.setValidations([]);
                token = response.payload.token;
                url = 'https://app.powerbi.com/reportEmbed?reportId=' + reportId;
                if (groupId) {
                    url = url + '&groupId=' + groupId;
                }
                if (tokenType) {
                    if (!(groupId && reportId)) {
                        Appian.Component.setValidations("Group Id or Report Id should not be null.");
                        return;
                    }
                    var xhr = new XMLHttpRequest();
                    var tokenUrl = "https://api.powerbi.com/v1.0/myorg/groups/" + groupId + "/reports/" + reportId + "/GenerateToken";
                    xhr.open("POST", tokenUrl, true);
                    xhr.setRequestHeader("Authorization", "Bearer " + token);
                    xhr.setRequestHeader("Content-Type", "application/json");
                    xhr.onreadystatechange = function() {
                        if (xhr.readyState === 4 && xhr.status === 200) {
                            var json = JSON.parse(xhr.responseText);
                            embedToken = json["token"];
                            resetReport();
                        } else if (xhr.readyState === 4 && xhr.status !== 200) {
                            Appian.Component.setValidations("Error happened while fetching embed token. Please check whether the inputs are valid.");
                        }
                    }
                    var data = JSON.stringify({
                        "accessLevel": "View"
                    });
                    xhr.send(data);
                } else {
                    resetReport();
                }
            })
            .catch(function(error) {
                Appian.Component.setValidations(error);
            });
    }
});