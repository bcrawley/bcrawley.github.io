/* global powerbi */
var token, tileId, dashboardId, tokenType, embedToken, connectedSystem, groupId, url;
function resetTile() {
  var config = {
    type: 'tile',
    tokenType: tokenType,
    accessToken: tokenType ? embedToken : token,
    embedUrl: url,
    id: tileId,
    settings: {
      background: 1,
    },
    dashboardId: dashboardId
  };
  var embedContainer = $('#tileContainer')[0];
  var tile = powerbi.embedNew(embedContainer, config);

  tile.off('tileLoaded');
  tile.on('tileLoaded', function () { });

  tile.off('error');
  tile.on('error', function (event) {
    Appian.Component.saveValue('onError', {
      event: event.detail
    });
  });

  tile.on('tileClicked', function (event) {
    Appian.Component.saveValue('onTileClicked', {
      event: event.detail
    });
  });
}

Appian.Component.onNewValue(function (newParameters) {
  document.body.style.height = newParameters['height'];
  groupId = newParameters['groupId'];
  dashboardId = newParameters['dashboardId'];
  tileId = newParameters['tileId'];
  tokenType = newParameters['isAppDataConnectedSystem'] ? 1 : 0;
  connectedSystem = newParameters['powerBIConnectedSystem'];
  if (connectedSystem != null && dashboardId != null && tileId != null) {
    var payload = groupId ? { groupId: groupId, dashboardId: dashboardId, tileId: tileId, embedType: 0 } : { dashboardId: dashboardId, tileId: tileId, embedType: 0 };
    Appian.Component.invokeClientApi(connectedSystem, 'GenerateEmbedTokenClientApi', payload).then(function (response) {
      Appian.Component.setValidations([]);
      token = response.payload.token;
      url = 'https://app.powerbi.com/embed?dashboardId=' + dashboardId + '&tileId=' + tileId;
      if (groupId) {
        url = url + '&groupId=' + groupId;
      }
      if (tokenType) {
        if (!(groupId && dashboardId && tileId)) {
          Appian.Component.setValidations("Group Id, Dashboard Id and Tile Id should not be null.");
          return;
        }
        var xhr = new XMLHttpRequest();
        var tokenUrl = "https://api.powerbi.com/v1.0/myorg/groups/" + groupId + "/dashboards/" + dashboardId + "/tiles/" + tileId + "/GenerateToken";
        xhr.open("POST", tokenUrl, true);
        xhr.setRequestHeader("Authorization", "Bearer " + token);
        xhr.setRequestHeader("Content-Type", "application/json");
        xhr.onreadystatechange = function () {
          if (xhr.readyState === 4 && xhr.status === 200) {
            var json = JSON.parse(xhr.responseText);
            embedToken = json["token"];
            resetTile();
          }
          else if (xhr.readyState === 4 && xhr.status !== 200) {
            Appian.Component.setValidations("Error happened while fetching embed token. Please check whether the inputs are valid.");
          }
        }
        var data = JSON.stringify({
          "accessLevel": "View"
        });
        xhr.send(data);
      }
      else {
        resetTile();
      }
    })
      .catch(function (error) {
        Appian.Component.setValidations(error);
      });
  }
});