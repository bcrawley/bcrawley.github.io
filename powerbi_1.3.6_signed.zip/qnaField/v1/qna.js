/* global powerbi */
var token, groupId, datasetId, url, tokenType, embedToken, connectedSystem;
function resetQnA() {
  var config= {
    type: 'qna',
    tokenType: tokenType,
    accessToken: tokenType ? embedToken : token,
    embedUrl: url,
    datasetIds: [datasetId],
    viewMode: 0,
    settings: {
      background: 1,
    }
  };

  var embedContainer = $('#qnaContainer')[0]; 
  powerbi.embedNew(embedContainer, config);   
}

Appian.Component.onNewValue(function(newParameters) {
  document.body.style.height = newParameters['height'];
  groupId = newParameters['groupId'];
  datasetId = newParameters['datasetId'];
  tokenType = newParameters['isAppDataConnectedSystem'] ? 1 : 0;
  connectedSystem = newParameters['powerBIConnectedSystem'];
  if (connectedSystem != null && datasetId != null) {
    var payload = groupId ? {groupId: groupId, datasetId: datasetId, embedType: 0} : {datasetId: datasetId, embedType: 0};
    Appian.Component.invokeClientApi(connectedSystem, 'GenerateEmbedTokenClientApi', payload).then(function(response) {
      Appian.Component.setValidations([]);
      token = response.payload.token;
      url = 'https://app.powerbi.com/qnaEmbed';
      if (groupId){
        url = url + '?groupId=' + groupId;
      }
      if (tokenType) {
        if (!(groupId && datasetId)) {
          Appian.Component.setValidations("Group Id or Dataset Id should not be null.");
          return;
        }
        var xhr = new XMLHttpRequest();
        var tokenUrl = "https://api.powerbi.com/v1.0/myorg/groups/" + groupId + "/datasets/"+datasetId+"/GenerateToken";
        xhr.open("POST", tokenUrl, true);
        xhr.setRequestHeader("Authorization", "Bearer " + token);
        xhr.setRequestHeader("Content-Type", "application/json");
        xhr.onreadystatechange = function () {
          if (xhr.readyState === 4 && xhr.status === 200) {
            var json = JSON.parse(xhr.responseText);
            embedToken = json["token"];
            resetQnA();
          }
          else if (xhr.readyState === 4 && xhr.status !== 200) {
            Appian.Component.setValidations("Error happened while fetching embed token. Please check whether the inputs are valid.");
          }
        }
        var data = JSON.stringify({
          "accessLevel": "View"
        });
        xhr.send(data);
      }
      else {
        resetQnA();
      }
    })
      .catch(function(error) {
        Appian.Component.setValidations(error);
      });
  } 
});